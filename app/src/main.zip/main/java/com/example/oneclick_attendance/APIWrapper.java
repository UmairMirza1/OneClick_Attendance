package com.example.oneclick_attendance;


import java.util.ArrayList;

public class APIWrapper {

APIWrapper(){}

    public ArrayList<String> GetAPIData(){

    return null;
    }

}
