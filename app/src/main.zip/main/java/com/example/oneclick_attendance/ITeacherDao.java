package com.example.oneclick_attendance;

import java.util.Hashtable;

public interface ITeacherDao {

    //void saveTeacher(Hashtable<String, String> teacher);

    void saveTeacher(Teacher teacher);
    void saveAttendance(Attendance attendance);

    void addSection(Section section);

    void loadTeacher(String email);
}
