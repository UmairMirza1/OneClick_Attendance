package com.example.oneclick_attendance;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class SectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_section);
    }
}

