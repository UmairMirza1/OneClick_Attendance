package com.example.oneclick_attendance;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class DashboardActivity extends AppCompatActivity {


    String userId;

    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;

    DashboardViewModel Vm;
    DashboardAdapter mAdapter;
    ITeacherDao dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        getDataFromIntent();
        SetViews();
        SetVmAndRv();




    }

    private void SetVmAndRv() {
        dao = new TeacherFirebaseDAO(new TeacherFirebaseDAO.observer() {
            @Override
            public void update() {
                RefreshDataSet();
            }
        });
        Vm = new DashboardViewModel(userId, dao);
        //mAdapter = new DashboardAdapter(Vm);


    }

    private void RefreshDataSet() {
        // Call  mAdapter.notifyDataSetChanged();
    }

    private void SetViews() {

    }

    private void getDataFromIntent() {
        Intent intent = getIntent();
        userId = intent.getStringExtra("UserId");
    }


}
