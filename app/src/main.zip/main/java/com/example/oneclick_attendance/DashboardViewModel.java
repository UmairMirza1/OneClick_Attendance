package com.example.oneclick_attendance;

import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

public class DashboardViewModel extends ViewModel {

    private ArrayList<Section> sections;

    ITeacherDao dao;

    private String email;

    DashboardViewModel(String email, ITeacherDao dao){
        this.email = email;
        this.dao = dao;
        sections = new ArrayList<>();
    }


    // TODO: Save a new section
    public void addSection(Section section){
        if (dao != null){
            dao.addSection(section);
        }
        else{
            sections.add(section);
        }
    }


    public void setDao(ITeacherDao d){
        dao = d;
    }

    public void setemail ( String email ){  this.email=email;}

//    public ArrayList<Section>  update(){
//        if (dao != null){
//            sections = Section.load(dao);
//        }
//        else sections = new ArrayList<Section>();
//        return sections;
//    }


//    public ArrayList<Section> getSections(String email){
//        if (sections == null){
//            if (dao != null){
//                sections = Section.load(dao,email);
//            }
//            else sections = new ArrayList<Section>();
//        }
//        else{
//            //sections = (ArrayList<Section>) savedInstanceState.get(key);
//            sections = new ArrayList<Section>();
//        }
//        return sections;
//    }

}
